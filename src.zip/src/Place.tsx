import React, { useState, useEffect } from "react"
import { v4 as uuid } from "uuid"

export default function Place() {
    const [websocket, setWebsocket] = useState<WebSocket | null>(null);
    const [messages, setMessages] = useState<Array<string>>([]);
    const [message, setMessage] = useState<string>("");
    const [activeClients, setActiveClients] = useState<Array<string>>([]);
    const [inactiveClients, setInactiveClients] = useState<Array<string>>([]);
    
    const onSubmit = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        if (message !== "") {
            websocket?.send(JSON.stringify({type: "CLIENT_MESSAGE", data: message}));
            setMessage("");
        }
    };
    
    useEffect(() => {
        const client_id = uuid()
        const websocketConnection = new WebSocket("ws://localhost:8000/ws/" + client_id);
        setWebsocket(websocketConnection);
    }, []);

    useEffect(() => {
        if (websocket) {
            websocket.onmessage = (event) => {
                let websocketData: {type: string, data: any} = JSON.parse(event.data);
                if (websocketData.type === "CLIENT_DATA") {
                    let clientData: {active_clients: Array<string>, inactive_clients: Array<string>} = websocketData.data;
                    setActiveClients(clientData.active_clients);
                    setInactiveClients(clientData.inactive_clients);
                } else if (websocketData.type === "CLIENT_DISCONNECT") {
                    const clientId = websocketData.data;
                    let newActiveClients = [...activeClients];
                    newActiveClients = newActiveClients.filter((activeClient: string) => {return activeClient !== clientId});
                    let newInactiveClients = [...inactiveClients];
                    newInactiveClients.push(clientId);
                    setActiveClients(newActiveClients);
                    setInactiveClients(newInactiveClients);
                } else if (websocketData.type === "CLIENT_MESSAGE") {
                    const newMessage = websocketData.data;
                    const newMessages = [...messages];
                    newMessages.push(newMessage);
                    setMessages(newMessages);
                }
            };
        }
    }, [websocket, messages, activeClients, inactiveClients]);
    
    return <div>
        <div>
            <form onSubmit={onSubmit}>
                <input type="text" value={message} onChange={(e) => {setMessage(e.target.value);}} />
                <button type="submit">place</button>
            </form>
        </div>
        <div>
            {messages.map((text: string, index: number) => {
                return <div key={index}>{text}</div>;
            })}
        </div>
        <div style={{color: "yellow"}}>
            {activeClients.map((activeClient: string, index: number) => {
                return <div key={index}>{activeClient}</div>;
            })}
        </div>
        <div style={{color: "red"}}>
            {inactiveClients.map((inactiveClient: string, index: number) => {
                return <div key={index}>{inactiveClient}</div>;
            })}
        </div>
    </div>;
}