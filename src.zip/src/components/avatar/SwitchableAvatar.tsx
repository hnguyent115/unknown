import { Avatar, AvatarProps } from "@material-tailwind/react"
import { isImageValid } from "../../shared-actions/data-operations/dataOperations"
import TextAvatar from "./TextAvatar"

export interface ISwitchableAvatarProps extends AvatarProps {

}

export default function SwitchableAvatar({ src, alt, size, variant, color, withBorder, className }: ISwitchableAvatarProps) {
    const inputSrc = (src !== undefined) ? src : "";
    const inputAlt = (alt !== undefined) ? alt : "";
    const avatar = isImageValid(inputSrc) ? <Avatar src={inputSrc} alt={inputAlt} size={size} variant={variant} color={color} withBorder={withBorder} className={className} placeholder="" /> : <TextAvatar text={inputAlt} size={size} variant={variant} color={color} withBorder={withBorder} className={className} />;
    
    return (
        <>
            {avatar}
        </>
    );
}