import { AvatarProps } from "@material-tailwind/react"

export interface ITextAvatarProps extends AvatarProps {
    text: string
}

export default function TextAvatar({ text, size, variant, withBorder, color, className = "" }: ITextAvatarProps) {
    const avatarSize = {
        xs: "h-6 w-6",
        sm: "h-9 w-9",
        md: "h-12 w-12",
        lg: "h-[58px] w-[58px]",
        xl: "h-[74px] w-[74px]",
        xxl: "h-[110px] w-[110px]"
    };

    const avatarVariant = {
        circular: "rounded-full",
        rounded: "rounded-md",
        square: "rounded-none"
    };

    const avatarColor = {
        white: "border-white",
        "blue-gray": "border-blue-gray-500",
        gray: "border-gray-900",
        brown: "border-brown-500",
        "deep-orange": "border-deep-orange-500",
        orange: "border-orange-500",
        amber: "border-amber-500",
        yellow: "border-yellow-500",
        lime: "border-lime-500",
        "light-green": "border-light-green-500",
        green: "border-green-500",
        teal: "border-teal-500",
        cyan: "border-cyan-500",
        "light-blue": "border-light-blue-500",
        blue: "border-blue-500",
        indigo: "border-indigo-500",
        "deep-purple": "border-deep-purple-500",
        purple: "border-purple-500",
        pink: "border-pink-500",
        red: "border-red-500",
    };
    
    const inputSize = (size !== undefined && typeof size === "string" && avatarSize[size] !== undefined) ? "!" + avatarSize[size] : "";
    const inputBorder = (withBorder !== undefined && typeof withBorder === "boolean") ? "!border-2" : "";
    const inputColor = (color !== undefined && typeof color === "string" && avatarColor[color] !== undefined) ? "!" + avatarColor[color] : "";
    const inputVariant = (variant !== undefined && typeof variant === "string" && avatarVariant[variant] !== undefined) ? "!" + avatarVariant : "";
    
    return (
        <span className={`flex h-9 w-9 ${inputSize} bg-[rgba(121,124,140,1)] justify-center items-center border-0 ${inputBorder} border-solid border-yellow-500 ${inputColor} rounded-full ${inputVariant} text-[#ffffff] font-[500] text-sm ${className}`}>{text !== "" ? text.charAt(0) : "A"}</span>
    );
}