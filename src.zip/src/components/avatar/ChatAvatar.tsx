import { AvatarProps } from "@material-tailwind/react"
import SwitchableAvatar from "./SwitchableAvatar"

export interface IChatAvatarProps extends AvatarProps {
    isActive: boolean
}

export default function ChatAvatar({ src, alt, size, isActive, className = "" }: IChatAvatarProps) {
    return (
        <span className="relative inline-block">
            <SwitchableAvatar src={src} alt={alt} size={size} className={className} />
            <span className={`absolute left-auto right-0 bottom-0 h-[10px] w-[10px] ${(isActive ? "bg-[#06d6a0]" : "bg-[#adb5bd]")} border-2 border-solid border-[#ffffff] rounded`}></span>
        </span>
    );
}