import { IBaseComponentProps } from "../../models/interfaces/component-props/componentProps"

export interface ISecondaryLogoProps extends IBaseComponentProps {
    fontSize?: string,
    color?: string
}

export default function SecondaryLogo({ fontSize = "30px", color = "#4eac6d", className = "" }: ISecondaryLogoProps) {
    return (
        <a href="" className={`text-[${fontSize}] text-[${color}] ${className}`}>
            <i className="fa-solid fa-message"></i>
        </a>
    );
}