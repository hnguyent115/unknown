import { IBaseComponentProps } from "../../models/interfaces/component-props/componentProps"

export interface ILogoProps extends IBaseComponentProps {
    fontSize?: string,
    fontWeight?: string,
    color?: string
}

export default function Logo({ fontSize = "1.640625rem", fontWeight = "500", color = "#ffffff", className = "" }: ILogoProps) {
    return (
        <a href="" className={`text-[${fontSize}] text-[${color}] font-[${fontWeight}] ${className}`}>
            <i className="fa-solid fa-message me-[1rem]"></i>
            Doot
        </a>
    );
}