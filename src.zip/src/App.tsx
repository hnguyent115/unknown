import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './index.css'
import { BrowserRouter, Route, Routes } from "react-router-dom"
import Authentication from "./pages/authentication/Authentication"
import MainDashBoard from "./pages/main/MainDashBoard"

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="*" element={<MainDashBoard />} />
        <Route path="/authentication/*" element={<Authentication />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App
