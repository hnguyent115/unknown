import { FileType } from "../models/types/file-type/fileType"

export const LOGIN_PAGE: string = "/authentication"
export const REGISTER_PAGE: string = "/authentication/register"
export const MAIN_PAGE: string = "/"
export const PNG_TYPE: FileType = "png"
export const PDF_TYPE: FileType = "pdf"