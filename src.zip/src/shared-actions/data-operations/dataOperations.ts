export const isImageValid = (src: string): boolean => {
    let image = new Image();
    image.src = src;
    return image.width > 0;
};