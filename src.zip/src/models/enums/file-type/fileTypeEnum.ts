export enum FileTypeEnum {
    PNG = "png",
    PDF = "pdf"
}