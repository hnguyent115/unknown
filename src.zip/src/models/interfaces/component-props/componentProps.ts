export interface IBaseComponentProps {
    className?: string
}

export interface IBaseSwitchableComponentProps extends IBaseComponentProps {
    isSelected: boolean
}