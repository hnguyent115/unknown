export interface IUser {
    image: string,
    name: string
}