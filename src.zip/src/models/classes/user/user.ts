import { IUser } from "../../interfaces/user/user"

class User {
    image: string;
    name: string;
    
    constructor({ image, name }: IUser) {
        this.image = image;
        this.name = name;
    }
}

export default User;