import { Route, Routes } from "react-router-dom"
import AuthenticationLayout from "./layouts/authentication/AuthenticationLayout"
import Login from "./components/login/Login"
import Register from "./components/register/Register"

export default function Authentication() {
    return (
        <AuthenticationLayout>
            <Routes>
                <Route path="/" element={<Login />} />
                <Route path="/register" element={<Register />} />
            </Routes>
        </AuthenticationLayout>
    );
}