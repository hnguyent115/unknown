import Logo from "../../../../components/logo/Logo"
import React from "react";

export interface IAuthenticationLayoutProps {
    children: React.ReactElement
}

export default function AuthenticationLayout({ children }: IAuthenticationLayoutProps) {
    return (
        <div className="h-screen w-full bg-primary">
            <div className="grid grid-cols-3 xl:grid-cols-12 h-full">
                <div className="col-span-3 h-full">
                    <div className="p-12 pb-0 h-full"><Logo /></div>
                </div>
                <div className="col-span-9 h-full">
                    {children}
                </div>
            </div>
        </div>
    );
}