import { useState, FormEventHandler } from "react"
import { useLocation, Location, Navigate } from "react-router-dom"
import { LOGIN_PAGE } from "../../../../config/constant"

export default function Register() {
    const location: Location = useLocation();
    const [nextLocation, setNextLocation] = useState<string>(location.pathname);
    
    const onSubmit: FormEventHandler<HTMLFormElement> = (event: React.FormEvent<HTMLFormElement>) => {
        setNextLocation(LOGIN_PAGE);
    };
    
    return (
        <div className="bg-[#ffffff] h-[calc(100%-48px)] m-[24px] rounded-2xl">
            <div className="flex flex-col h-full p-6 pb-0">
                <div className="justify-center my-auto grid grid-cols-12">
                    <div className="col-start-5 col-span-4 col-end-9">
                        <div className="py-12">
                            <div className="text-center mb-12">
                                <h3 className="text-text-primary-color font-[500] text-[1.640625rem] leading-[1.2] mb-2">Register Account</h3>
                                <p className="text-text-secondary-color font-[400] text-[.9375rem] mb-4">Get your free Doot account now.</p>
                            </div>
                            <div className="relative">
                                <form onSubmit={onSubmit}>
                                    <div className="mb-4">
                                        <label className="mb-2 font-[500] inline-block text-[0.9375rem] text-text-primary-color">Email</label>
                                        <input type="text" className="w-full block border border-solid border-[#eaeaf1] rounded text-text-primary-color font-[400] text-[.875rem] py-2 px-4 focus:outline-none" placeholder="Enter email" />
                                    </div>
                                    <div className="mb-4">
                                        <label className="mb-2 font-[500] inline-block text-[0.9375rem] text-text-primary-color">Username</label>
                                        <input type="text" className="w-full block border border-solid border-[#eaeaf1] rounded text-text-primary-color font-[400] text-[.875rem] py-2 px-4 focus:outline-none" placeholder="Enter username" />
                                    </div>
                                    <div className="mb-4">
                                        <div className="block float-right">
                                            <a href="" className="text-text-secondary-color outline-none font-[400] text-[0.9375rem]">Forgot password?</a>
                                        </div>
                                        <label className="mb-2 font-[500] inline-block text-[0.9375rem] text-text-primary-color">Password</label>
                                        <div className="relative block mb-4">
                                            <input type="text" className="w-full block border border-solid border-[#eaeaf1] rounded text-text-primary-color font-[400] text-[.875rem] py-2 px-4 pr-12 focus:outline-none" placeholder="Enter password" />
                                            <button type="button" className="absolute right-0 top-0 text-text-primary-color py-2 px-4 text-[.875rem]"><i className="fa-solid fa-eye align-middle"></i></button>
                                        </div>
                                    </div>
                                    <div className="mb-6">
                                        <p className="text-text-primary-color font-[400] text-[.9375rem] leading-normal">By registering you agree to the Doot <a href="" className="text-primary">Terms of Use</a></p>
                                    </div>
                                    <div className="block mb-4 text-center">
                                        <button type="submit" className="w-full bg-primary border border-solid border-primary rounded text-[#ffffff] font-[400] text-[0.9375rem] text-center py-2 px-4 hover:bg-[#42925d] hover:border-[#3e8a57] active:bg-[#3e8a57] active:border-[#3b8152]">Register</button>
                                    </div>
                                    <div className="block mt-6 text-center">
                                        <div className="relative block after:content-[''] after:bg-[#eaeaf1] after:h-[1px] after:w-full after:absolute after:left-0 after:right-0 after:top-[10px]">
                                            <h5 className="relative inline-block bg-[#ffffff] z-[9] mb-6 text-text-primary-color font[500] text-sm py-[2px] px-[16px]">Sign up using</h5>
                                        </div>
                                        <div className="grid grid-cols-12 gap-x-2.5">
                                            <div className="col-span-4">
                                                <button type="button" className="w-full bg-[#f6f6f9] border border-solid border-[#f6f6f9] rounded font-[400] text-[0.9375rem] text-center py-2 px-4 hover:bg-[#d1d1d4] hover:border-[#c5c5c7] active:bg-[#c5c5c7] active:border-[#b9b9bb]"><i className="fa-brands fa-facebook"></i></button>
                                            </div>
                                            <div className="col-span-4">
                                                <button type="button" className="w-full bg-[#f6f6f9] border border-solid border-[#f6f6f9] rounded font-[400] text-[0.9375rem] text-center py-2 px-4 hover:bg-[#d1d1d4] hover:border-[#c5c5c7] active:bg-[#c5c5c7] active:border-[#b9b9bb]"><i className="fa-brands fa-twitter"></i></button>
                                            </div>
                                            <div className="col-span-4">
                                                <button type="button" className="w-full bg-[#f6f6f9] border border-solid border-[#f6f6f9] rounded font-[400] text-[0.9375rem] text-center py-2 px-4 hover:bg-[#d1d1d4] hover:border-[#c5c5c7] active:bg-[#c5c5c7] active:border-[#b9b9bb]"><i className="fa-brands fa-google"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                                <div className="mt-12 text-center">
                                    <p className="mb-4 text-text-secondary-color font-[400] text-[.9375rem]">Already have an account ? <a href={LOGIN_PAGE} className="underline text-primary font-[500] text-[.9375rem]">Login</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="grid grid-cols-12 xl:grid-cols-12">
                    <div className="col-span-12">
                        <div className="text-center text-text-secondary-color font-[400] text-[.9375rem] p-6">
                            <p className="">2024</p>
                        </div>
                    </div>
                </div>
            </div>
            {nextLocation !== location.pathname && <Navigate to={nextLocation} />}
        </div>
    );
}