import ScrollableLayout from "../../layouts/scrollable/ScrollableLayout"
import Contact from "../contact/Contact"
import { useState } from "react"
import { IContactProps } from "../contact/Contact"

export default function Contacts() {
    const [contacts, setContacts] = useState<Array<IContactProps>>([
        {
            character: "A",
            contactItems: [
                {
                    name: "Alvarez Luna",
                    image: ""
                }
            ]
        },
        {
            character: "C",
            contactItems: [
                {
                    name: "Carla Serrano",
                    image: "https://doot-light.react.themesbrand.com/static/media/avatar-1.9c8e605558cece65b06c.jpg"
                }
            ]
        },
        {
            character: "D",
            contactItems: [
                {
                    name: "Dean Vargas",
                    image: ""
                },
                {
                    name: "Donaldson Riddle",
                    image: "https://doot-light.react.themesbrand.com/static/media/avatar-10.da0d54a94675f412b849.jpg"
                },
                {
                    name: "Daniels Webster",
                    image: ""
                }
            ]
        },
        {
            character: "E",
            contactItems: [
                {
                    name: "Earnestine Sears",
                    image: "https://doot-light.react.themesbrand.com/static/media/avatar-5.123e30b003e261b19f83.jpg"
                }
            ]
        },
        {
            character: "F",
            contactItems: [
                {
                    name: "Faulkner Benjamin",
                    image: "https://doot-light.react.themesbrand.com/static/media/avatar-5.123e30b003e261b19f83.jpg"
                }
            ]
        },
        {
            character: "H",
            contactItems: [
                {
                    name: "Heath Javis",
                    image: ""
                },
                {
                    name: "Hendrix Martin",
                    image: "https://doot-light.react.themesbrand.com/static/media/avatar-9.d5a2756eadc507cc4593.jpg"
                }
            ]
        },
        {
            character: "J",
            contactItems: [
                {
                    name: "Jennifer Ramirez",
                    image: "https://doot-light.react.themesbrand.com/static/media/avatar-7.33a3b9888f7f69c57704.jpg"
                }
            ]
        },
        {
            character: "K",
            contactItems: [
                {
                    name: "Katrina Winters",
                    image: "https://doot-light.react.themesbrand.com/static/media/avatar-3.6256d30dbaad2b8f4e60.jpg"
                },
                {
                    name: "Kitty Cannon",
                    image: ""
                }
            ]
        },
        {
            character: "M",
            contactItems: [
                {
                    name: "Marguerite Campbell",
                    image: "https://doot-light.react.themesbrand.com/static/media/avatar-4.474927d6a33a7b8cde52.jpg"
                },
                {
                    name: "Miranda Valentine",
                    image: ""
                },
                {
                    name: "Melody Montoya",
                    image: ""
                }
            ]
        },
        {
            character: "N",
            contactItems: [
                {
                    name: "Norris Decker",
                    image: "https://doot-light.react.themesbrand.com/static/media/avatar-2.81ae8bcabb014e1f71b8.jpg"
                }
            ]
        },
        {
            character: "S",
            contactItems: [
                {
                    name: "Sanford Phelps",
                    image: ""
                },
                {
                    name: "Shawna Wright",
                    image: ""
                }
            ]
        },
        {
            character: "T",
            contactItems: [
                {
                    name: "Tonia Clay",
                    image: "https://doot-light.react.themesbrand.com/static/media/avatar-8.de8497f02cbe680f8457.jpg"
                }
            ]
        },
        {
            character: "W",
            contactItems: [
                {
                    name: "Wallace lane",
                    image: "https://doot-light.react.themesbrand.com/static/media/avatar-6.7b73a5460ee6291c1df6.jpg"
                }
            ]
        },
        {
            character: "Z",
            contactItems: [
                {
                    name: "Zimmerman Langley",
                    image: ""
                }
            ]
        }
    ]);
    
    return (
        <div className="h-full">
            <div className="h-full">
                <div className="flex flex-col relative h-full">
                    <div className="px-6 pt-6">
                        <div className="flex items-start">
                            <div className="grow">
                                <h4 className="mt-0 mb-6 text-text-primary-color font-[500] text-[1.3125rem] leading-[1.2]">Contacts</h4>
                            </div>
                            <div className="shrink-0">
                                <div className="">
                                    <button type="button" className="bg-[#4eac6d1a] border border-solid border-[#0000] rounded-[0.2rem] align-middle text-primary font-[400] text-[0.8203125rem] text-center py-1 px-2 hover:bg-primary hover:text-[#ffffff]">
                                        <i className="fa-solid fa-plus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <form className="">
                            <div className="flex flex-wrap relative mb-4 w-full items-stretch">
                                <input type="text" className="grow shrink basis-auto block relative w-[1%] min-w-0 bg-[rgba(246,246,249,1)] border-0 rounded-l text-text-primary-color font-[400] text-[.875rem] leading-normal outline-none py-2 px-4 pr-0" placeholder="Search Contacts..." />
                                <button type="submit" className="relative bg-[#f6f6f9] border border-solid border-[#f6f6f9] rounded-r align-middle text-[#212529] font-[400] text-[0.9375rem] text-center py-2 px-4 hover:bg-[#d1d1d4] hover:border-[#c5c5c7] active:bg-[#c5c5c7] active:border-[#b9b9bb]">
                                    <i className="fa-solid fa-magnifying-glass align-middle"></i>
                                </button>
                            </div>
                        </form>
                    </div>
                    <div className="grow relative">
                        <ScrollableLayout>
                            <div className="">
                                {contacts.map((contact: IContactProps, index: number) => {
                                    return <Contact key={index} character={contact.character} contactItems={contact.contactItems} />;
                                })}
                            </div>
                        </ScrollableLayout>
                    </div>
                </div>
            </div>
        </div>
    );
}