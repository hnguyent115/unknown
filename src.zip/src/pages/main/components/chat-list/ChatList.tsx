import ChatItem, { IChatItemProps } from "../chat-item/ChatItem"
import { IBaseComponentProps } from "../../../../models/interfaces/component-props/componentProps"

export interface IChatListProps extends IBaseComponentProps {
    chatItems: Array<IChatItemProps>
}

export default function ChatList({ chatItems, className = "" }: IChatListProps) {
    return (
        <div className={`${className}`}>
            <ul className="list-none pl-0">
                {chatItems.map((chatItem: IChatItemProps, index: number) => {
                    return <li key={index} className="">
                        <ChatItem name={chatItem.name} image={chatItem.image} isActive={chatItem.isActive} isStatusIndicated={chatItem.isStatusIndicated} isSelected={chatItem.isSelected} className="py-[5px] px-[24px]" />
                    </li>;
                })}
            </ul>
        </div>
    );
}