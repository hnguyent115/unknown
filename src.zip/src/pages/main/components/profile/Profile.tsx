import AttachedFile from "../attached-file/AttachedFile"
import { PNG_TYPE, PDF_TYPE } from "../../../../config/constant"
import ScrollableLayout from "../../layouts/scrollable/ScrollableLayout"
import SwitchableAvatar from "../../../../components/avatar/SwitchableAvatar"

export default function Profile() {
    return (
        <div className="h-full">
            <div className="h-full">
                <div className="flex flex-col relative h-full">
                    <div className="relative">
                        <img src="https://doot-light.react.themesbrand.com/static/media/img-4.8111c4656c8bc3b62569.jpg" className="h-40 w-full object-cover align-middle" />
                        <div className="flex flex-col absolute h-full left-0 right-0 top-0 bottom-0 bg-[linear-gradient(180deg,#00000080 10%,#0000 60%,#00000080)] text-[#fff9]">
                            <div className="">
                                <div className="p-2 pl-4">
                                    <div className="flex w-full items-center">
                                        <div className="grow">
                                            <h5 className="my-0 text-[#ffffff] font-[500] text-[1.171875rem] leading-[1.2]">My Profile</h5>
                                        </div>
                                        <div className="shrink-0">
                                            <div className="relative">
                                                <button type="button" className="h-[40px] w-[40px] border border-solid border-[#0000] text-[#ffffff] text-[22px] text-center leading-[40px] p-0 align-middle">
                                                    <i className="fa-solid fa-ellipsis-vertical"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="relative mt-[-3rem] border-b border-solid border-[#eaeaf1] text-center p-6 pt-2">
                        <div className="mb-4">
                            <SwitchableAvatar size="xl" alt="avatar" src="https://docs.material-tailwind.com/img/face-2.jpg" className="border-[calc(0.25rem+1px)] border-[#eaeaf1]" />
                        </div>
                        <h5 className="mt-0 mb-1 text-text-primary-color font-[500] text-base text-ellipsis leading-[1.2] overflow-hidden whitespace-nowrap">Adam Zampa</h5>
                        <p className="my-0 text-text-secondary-color font-[400] text-sm text-ellipsis overflow-hidden whitespace-nowrap">Front end Developer</p>
                    </div>
                    <div className="grow relative">
                        <ScrollableLayout>
                            <div className="p-6">
                                <div className="text-text-secondary-color">
                                    <p className="mb-6 mt-0 font-[400] text-[.9375rem] leading-normal">If several languages coalesce, the grammar of the resulting language is more simple</p>
                                </div>
                                <div className="">
                                    <div className="flex py-2">
                                        <div className="shrink-0 mr-4 text-[.9375rem]">
                                            <i className="fa-regular fa-user align-middle"></i>
                                        </div>
                                        <div className="grow">
                                            <p className="my-0 text-text-primary-color font-[400] text-[.9375rem]">Adam Zampa</p>
                                        </div>
                                    </div>
                                    <div className="flex py-2">
                                        <div className="shrink-0 mr-4 text-[.9375rem]">
                                            <i className="fa-regular fa-comment-dots"></i>
                                        </div>
                                        <div className="grow">
                                            <p className="my-0 text-text-primary-color font-[400] text-[.9375rem]">admin@themesbrand.com</p>
                                        </div>
                                    </div>
                                    <div className="flex py-2">
                                        <div className="shrink-0 mr-4 text-[.9375rem]">
                                            <i className="fa-solid fa-location-dot"></i>
                                        </div>
                                        <div className="grow">
                                            <p className="my-0 text-text-primary-color font-[400] text-[.9375rem]">California, USA</p>
                                        </div>
                                    </div>
                                </div>
                                <hr className="my-6 border-t border-solid text-[#adb5bd]"></hr>
                                <div className="">
                                    <div className="flex">
                                        <div className="grow">
                                            <h5 className="mt-0 mb-2 text-text-primary-color font-[500] text-[11px] uppercase">Media</h5>
                                        </div>
                                        <div className="shrink-0">
                                            <a href="" className="block mb-2 text-primary font-[400] text-[12px]">Show all</a>
                                        </div>
                                    </div>
                                    <div className="flex gap-2">
                                        <div className="relative">
                                            <a href="" className="relative block rounded overflow-hidden">
                                                <img src="https://doot-light.react.themesbrand.com/static/media/img-1.94735bdcb4171caaa01e.jpg" alt="" className="h-[76px] w-[76px] max-w-full object-cover align-middle" />
                                            </a>
                                        </div>
                                        <div className="relative">
                                            <a href="" className="relative block rounded overflow-hidden">
                                                <img src="https://doot-light.react.themesbrand.com/static/media/img-2.7f759d38502a81e71815.jpg" alt="" className="h-[76px] w-[76px] max-w-full object-cover align-middle" />
                                            </a>
                                        </div>
                                        <div className="relative">
                                            <a href="" className="relative block rounded overflow-hidden">
                                                <img src="https://doot-light.react.themesbrand.com/static/media/img-4.8111c4656c8bc3b62569.jpg" alt="" className="h-[76px] w-[76px] max-w-full object-cover align-middle" />
                                                <div className="flex absolute bg-[#212529b3] left-0 right-0 top-0 bottom-0 h-full w-full justify-center items-center text-[#ffffff]">+ 15</div>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <hr className="my-6 border-t border-solid text-[#adb5bd]"></hr>
                                <div className="">
                                    <div className="">
                                        <h5 className="mt-0 mb-4 text-text-secondary-color font-[500] text-[11px] leading-[1.2] uppercase">Attached Files</h5>
                                    </div>
                                    <div className="">
                                        <AttachedFile fileName="design-phase-1-approved" fileType={PDF_TYPE} fileCapacity="12.5 MB" className="mb-2" />
                                        <AttachedFile fileName="image-1" fileType={PNG_TYPE} fileCapacity="12.5 MB" className="mb-2" />
                                        <AttachedFile fileName="image-2" fileType={PNG_TYPE} fileCapacity="12.5 MB" className="mb-2" />
                                        <AttachedFile fileName="testing-A" fileType={PDF_TYPE} fileCapacity="12.5 MB" className="mb-2" />
                                    </div>
                                </div>
                            </div>
                        </ScrollableLayout>
                    </div>
                </div>
            </div>
        </div>
    );
}