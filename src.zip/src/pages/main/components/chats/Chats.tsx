import ScrollableLayout from "../../layouts/scrollable/ScrollableLayout"
import ChatList from "../chat-list/ChatList"
import { useState } from "react"
import { IChatItemProps } from "../chat-item/ChatItem"

export default function Chats() {
    const [favouriteChatMembers, setFavouriteChatMembers] = useState<Array<IChatItemProps>>([
        {
            name: "Marguerite Campbell",
            image: "https://doot-light.react.themesbrand.com/static/media/avatar-4.474927d6a33a7b8cde52.jpg",
            isActive: true,
            isStatusIndicated: true,
            isSelected: true
        },
        {
            name: "Katrina Winters",
            image: "https://doot-light.react.themesbrand.com/static/media/avatar-3.6256d30dbaad2b8f4e60.jpg",
            isActive: true,
            isStatusIndicated: true,
            isSelected: false
        },
        {
            name: "Miranda Valentine",
            image: "",
            isActive: true,
            isStatusIndicated: true,
            isSelected: false
        },
        {
            name: "Faulkner Benjamin",
            image: "https://doot-light.react.themesbrand.com/static/media/avatar-5.123e30b003e261b19f83.jpg",
            isActive: true,
            isStatusIndicated: true,
            isSelected: false
        }
    ]);

    const [directChatMembers, setDirectChatMembers] = useState<Array<IChatItemProps>>([
        {
            name: "Tonia Clay",
            image: "https://doot-light.react.themesbrand.com/static/media/avatar-8.de8497f02cbe680f8457.jpg",
            isActive: true,
            isStatusIndicated: true,
            isSelected: false
        },
        {
            name: "Hendrix Martin",
            image: "https://doot-light.react.themesbrand.com/static/media/avatar-9.d5a2756eadc507cc4593.jpg",
            isActive: false,
            isStatusIndicated: true,
            isSelected: false
        },
        {
            name: "Dean Vargas",
            image: "",
            isActive: true,
            isStatusIndicated: true,
            isSelected: false
        },
        {
            name: "Donaldson Riddle",
            image: "https://doot-light.react.themesbrand.com/static/media/avatar-10.da0d54a94675f412b849.jpg",
            isActive: true,
            isStatusIndicated: true,
            isSelected: false
        },
        {
            name: "Norris Decker",
            image: "https://doot-light.react.themesbrand.com/static/media/avatar-2.81ae8bcabb014e1f71b8.jpg",
            isActive: true,
            isStatusIndicated: true,
            isSelected: false
        },
        {
            name: "Zimmerman Langley",
            image: "",
            isActive: true,
            isStatusIndicated: true,
            isSelected: false
        }
    ]);

    const [channels, setChannels] = useState<Array<IChatItemProps>>([
        {
            name: "Landing Design",
            image: "",
            isStatusIndicated: false,
            isSelected: true
        },
        {
            name: "Design Phase 2",
            image: "",
            isStatusIndicated: false,
            isSelected: false
        },
        {
            name: "Brand Suggestion",
            image: "",
            isStatusIndicated: false,
            isSelected: true
        },
        {
            name: "Reporting",
            image: "",
            isStatusIndicated: false,
            isSelected: false
        }
    ]);
    
    return (
        <div className="h-full">
            <div className="h-full">
                <div className="flex flex-col h-full">
                    <div className="px-6 pt-6">
                        <div className="flex items-start">
                            <div className="grow">
                                <h4 className="mt-0 mb-6 text-text-primary-color font-[500] text-[1.3125rem] leading-[1.2]">Chats</h4>
                            </div>
                            <div className="shrink-0">
                                <div className="">
                                    <button type="button" className="bg-[#4eac6d1a] border border-solid border-[#0000] rounded-[0.2rem] align-middle text-primary font-[400] text-[0.8203125rem] text-center py-1 px-2 hover:bg-primary hover:text-[#ffffff]">
                                        <i className="fa-solid fa-plus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <form className="">
                            <div className="flex flex-wrap relative mb-4 w-full items-stretch">
                                <input type="text" className="grow shrink basis-auto block relative w-[1%] min-w-0 bg-[rgba(246,246,249,1)] border-0 rounded-l text-text-primary-color font-[400] text-[.875rem] leading-normal outline-none py-2 px-4 pr-0" placeholder="Search here..." />
                                <button type="submit" className="relative bg-[#f6f6f9] border border-solid border-[#f6f6f9] rounded-r align-middle text-[#212529] font-[400] text-[0.9375rem] text-center py-2 px-4 hover:bg-[#d1d1d4] hover:border-[#c5c5c7] active:bg-[#c5c5c7] active:border-[#b9b9bb]">
                                    <i className="fa-solid fa-magnifying-glass align-middle"></i>
                                </button>
                            </div>
                        </form>
                    </div>
                    <div className="grow relative">
                        <ScrollableLayout>
                            <h5 className="mt-6 mb-4 text-text-secondary-color font-[500] text-[11px] leading-[1.2] uppercase px-6">Favourites</h5>
                            <ChatList chatItems={favouriteChatMembers} />
                            <div className="flex mt-12 mb-2 items-center px-6">
                                <div className="grow">
                                    <h4 className="my-0 text-text-secondary-color font-[500] text-[11px] leading-[1.2] uppercase">Direct Messages</h4>
                                </div>
                                <div className="shrink-0">
                                    <div className="">
                                        <button type="button" className="bg-[#4eac6d1a] border border-solid border-[#0000] rounded-[0.2rem] align-middle text-primary font-[400] text-[0.8203125rem] text-center py-1 px-2 hover:bg-primary hover:text-[#ffffff]">
                                            <i className="fa-solid fa-plus"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <ChatList chatItems={directChatMembers} />
                            <div className="flex mt-12 mb-2 items-center px-6">
                                <div className="grow">
                                    <h4 className="my-0 text-text-secondary-color font-[500] text-[11px] leading-[1.2] uppercase">Channels</h4>
                                </div>
                                <div className="shrink-0">
                                    <div className="">
                                        <button type="button" className="bg-[#4eac6d1a] border border-solid border-[#0000] rounded-[0.2rem] align-middle text-primary font-[400] text-[0.8203125rem] text-center py-1 px-2 hover:bg-primary hover:text-[#ffffff]">
                                            <i className="fa-solid fa-plus"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <ChatList chatItems={channels} className="mb-4" />
                            <h5 className="mt-0 mb-2 text-text-primary-color font-[500] text-[1.171875rem] leading-[1.2] text-center">
                                <a href="" className="mt-6 mb-4 text-primary text-[11px] px-6">Archived Contacts <i className="fa-solid fa-box-archive align-middle"></i></a>
                            </h5>
                        </ScrollableLayout>
                    </div>
                </div>
            </div>
        </div>
    );
}