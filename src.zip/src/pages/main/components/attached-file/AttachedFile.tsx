import AvatarIcon from "../avatar-icon/AvatarIcon"
import { FileType } from "../../../../models/types/file-type/fileType"
import { IBaseComponentProps } from "../../../../models/interfaces/component-props/componentProps"
import { PNG_TYPE, PDF_TYPE } from "../../../../config/constant"

export interface IAttachedFileProps extends IBaseComponentProps {
    fileName: string
    fileType: FileType,
    fileCapacity: string
}

export default function AttachedFile({ fileName, fileType, fileCapacity, className = "" }: IAttachedFileProps) {
    const getAvatarIcon: Function = (fileTypeInput: FileType) => {
        switch(fileTypeInput) {
            case PNG_TYPE:
                return "fa-regular fa-image";
            case PDF_TYPE:
                return "fa-regular fa-file-lines";
        }
    };
    
    return (
        <div className={`relative min-w-0 border border-solid border-[#eaeaf1] rounded p-2 ${className}`}>
            <div className="flex items-center">
                <div className="shrink-0 ml-1 mr-4 h-[1.8rem] w-[1.8rem]">
                    <AvatarIcon className={getAvatarIcon(fileType)} />
                </div>
                <div className="grow overflow-hidden">
                    <h5 className="mt-0 mb-1 truncate text-text-primary-color font-[500] text-sm leading-[1.2]">{fileName}.{fileType}</h5>
                    <p className="my-0 text-text-secondary-color font-[400] text-[13px]">{fileCapacity}</p>
                </div>
                <div className="shrink-0 ml-4">
                    <div className="flex gap-2">
                        <div className="flex justify-center items-center">
                            <a href="" className="text-text-primary-color font-[400] text-[.9375rem] px-1">
                                <i className="fa-solid fa-download"></i>
                            </a>
                        </div>
                        <div className="relative">
                            <button type="button" className="border border-solid border-[#0000] rounded text-text-secondary-color font-[400] text-[0.9375rem] text-center align-middle py-2 px-1">
                                <i className="fa-solid fa-ellipsis"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}