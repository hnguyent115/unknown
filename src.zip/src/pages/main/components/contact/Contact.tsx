import ContactList, { IContactListProps } from "../contact-list/ContactList"

export interface IContactProps extends IContactListProps {
    character: string
}

export default function Contact({ character, contactItems, className = "" }: IContactProps) {
    return (
        <div className="mt-4">
            <div className={`relative text-primary font-[500] text-[12px] leading-normal py-[6px] px-[24px] after:content[''] after:absolute after:h-[1px] after:left-[50px] after:right-0 after:top-[50%] after:bg-[#eaeaf1] ${className}`}>{character}</div>
            <ContactList contactItems={contactItems} className="mb-4" />
        </div>
    );
}