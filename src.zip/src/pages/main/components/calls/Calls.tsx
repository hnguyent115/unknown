import ScrollableLayout from "../../layouts/scrollable/ScrollableLayout"

export default function Calls() {
    return (
        <div className="h-full">
            <div className="h-full">
                <div className="flex flex-col relative h-full">
                    <div className="px-6 pt-6">
                        <div className="flex items-start">
                            <div className="grow">
                                <h4 className="mt-0 mb-6 text-text-primary-color font-[500] text-[1.3125rem] leading-[1.2]">Contacts</h4>
                            </div>
                            <div className="shrink-0">
                                <div className="">
                                    <button type="button" className="bg-[#4eac6d1a] border border-solid border-[#0000] rounded-[0.2rem] align-middle text-primary font-[400] text-[0.8203125rem] text-center py-1 px-2 hover:bg-primary hover:text-[#ffffff]">
                                        <i className="fa-solid fa-plus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <form className="">
                            <div className="flex flex-wrap relative mb-4 w-full items-stretch">
                                <input type="text" className="grow shrink basis-auto block relative w-[1%] min-w-0 bg-[rgba(246,246,249,1)] border-0 rounded-l text-text-primary-color font-[400] text-[.875rem] leading-normal outline-none py-2 px-4 pr-0" placeholder="Search Contacts..." />
                                <button type="submit" className="relative bg-[#f6f6f9] border border-solid border-[#f6f6f9] rounded-r align-middle text-[#212529] font-[400] text-[0.9375rem] text-center py-2 px-4 hover:bg-[#d1d1d4] hover:border-[#c5c5c7] active:bg-[#c5c5c7] active:border-[#b9b9bb]">
                                    <i className="fa-solid fa-magnifying-glass align-middle"></i>
                                </button>
                            </div>
                        </form>
                    </div>
                    <div className="grow relative">
                        <ScrollableLayout>
                            <div>place</div>
                        </ScrollableLayout>
                    </div>
                </div>
            </div>
        </div>
    );
}