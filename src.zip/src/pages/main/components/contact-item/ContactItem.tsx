import SwitchableAvatar from "../../../../components/avatar/SwitchableAvatar"
import { IBaseComponentProps } from "../../../../models/interfaces/component-props/componentProps"

export interface IContactItemProps extends IBaseComponentProps {
    name: string,
    image: string
}

export default function ContactItem({ name, image, className = "" }: IContactItemProps) {
    return (
        <div className={`flex items-center ${className}`}>
            <div className="shrink-0 mr-2">
                <SwitchableAvatar src={image} alt={name} size="sm" />
            </div>
            <div className="grow overflow-hidden">
                <div className={`my-0 truncate text-text-primary-color font-[600] text-sm`}>{name}</div>
            </div>
            <div className="shrink-0">
                <a href="" className="text-primary font-[400] text-[.9375rem]"><i className="fa-solid fa-ellipsis-vertical"></i></a>
            </div>
        </div>
    );
}