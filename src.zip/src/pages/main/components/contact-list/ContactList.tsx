import { IBaseComponentProps } from "../../../../models/interfaces/component-props/componentProps"
import ContactItem, {IContactItemProps} from "../contact-item/ContactItem"

export interface IContactListProps extends IBaseComponentProps {
    contactItems: Array<IContactItemProps>
}

export default function ContactList({ contactItems, className = "" }: IContactListProps) {
    return (
        <ul className={`list-none pl-0 ${className}`}>
            {contactItems.map((contactItem: IContactItemProps, index: number) => {
                return <li key={index} className="cursor-pointer py-[8px] px-[24px]">
                    <ContactItem name={contactItem.name} image={contactItem.image} />
                </li>;
            })}
        </ul>
    );
}