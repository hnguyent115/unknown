import { IBaseComponentProps } from "../../../../models/interfaces/component-props/componentProps"

export default function AvatarIcon({ className = "" }: IBaseComponentProps) {
    return (
        <div className="flex h-full w-full bg-[#dceee2] justify-center items-center rounded-full text-primary font-[500] text-[.9375rem]">
            <i className={`${className}`}></i>
        </div>
    );
}