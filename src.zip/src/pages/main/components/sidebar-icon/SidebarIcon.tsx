import { IBaseComponentProps } from "../../../../models/interfaces/component-props/componentProps"

export default function SidebarIcon({ className = "" }: IBaseComponentProps) {
    return (
        <a href="#" className="relative block h-[56px] w-full text-[#878a92] font-[500] text-[23px] text-center leading-[56px] p-0 before:content-[''] before:absolute before:h-[20px] before:w-[2px] before:top-[18px] before:right-[-8px] focus:text-primary focus:before:bg-primary">
            <i className={`${className} align-middle`}></i>
        </a>
    );
}