import SecondaryLogo from "../../../../components/logo/SecondaryLogo"
import SidebarIcon from "../sidebar-icon/SidebarIcon"
import SwitchableAvatar from "../../../../components/avatar/SwitchableAvatar"

export default function Sidebar() {
    return (
        <div className="flex flex-col h-screen min-h-[570px] min-w-[75px] max-w-[75px] bg-[#2e2e2e] border border-solid border-[#2e2e2e] px-2">
            <div className="text-center">
                <SecondaryLogo className="leading-[70px]" />
            </div>
            <div className="flex flex-col h-full">
                <ul className="flex flex-col flex-wrap list-none h-full mt-0 p-0">
                    <li className="block w-full my-[7px]">
                        <SidebarIcon className="fa-regular fa-circle-user" />
                    </li>
                    <li className="block w-full my-[7px]">
                        <SidebarIcon className="fa-solid fa-comments" />
                    </li>
                    <li className="block w-full my-[7px]">
                        <SidebarIcon className="fa-solid fa-users" />
                    </li>
                    <li className="block w-full my-[7px]">
                        <SidebarIcon className="fa-solid fa-phone-volume" />
                    </li>
                    <li className="block w-full my-[7px]">
                        <SidebarIcon className="fa-solid fa-bookmark" />
                    </li>
                    <li className="block w-full my-[7px]">
                        <SidebarIcon className="fa-solid fa-gear" />
                    </li>
                    <li className="relative block w-full my-[7px] mt-auto">
                        <a href="" className="relative block h-[56px] w-full text-center leading-[56px] p-0"><SwitchableAvatar size="sm" alt="avatar" src="https://docs.material-tailwind.com/img/face-2.jpg" className="border-[3px] border-[#eaeaf1]" /></a>
                    </li>
                </ul>
            </div>
        </div>
    );
}