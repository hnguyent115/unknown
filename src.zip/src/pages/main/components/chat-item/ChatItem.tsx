import ChatAvatar from "../../../../components/avatar/ChatAvatar"
import { IBaseSwitchableComponentProps } from "../../../../models/interfaces/component-props/componentProps"
import SwitchableAvatar from "../../../../components/avatar/SwitchableAvatar"

export interface IChatItemProps extends IBaseSwitchableComponentProps {
    name: string,
    image: string,
    isActive?: boolean,
    isStatusIndicated: boolean
}

export default function ChatItem({ name, image, isActive, isStatusIndicated, isSelected, className = "" }: IChatItemProps) {
    const inputIsActive = (isActive !== undefined && typeof isActive === "boolean") ? isActive : false;
    const avatar = isStatusIndicated ? <ChatAvatar src={image} alt={name} size="sm" isActive={inputIsActive} /> : <SwitchableAvatar src={image} alt={name} size="sm" />;
    
    return (
        <a href="" className={`block ${className}`}>
            <div className="flex items-center">
                <div className="mr-2">
                    {avatar}
                </div>
                <div className="grow overflow-hidden">
                    <div className={`my-0 truncate text-text-primary-color ${(isSelected ? "font-[600]" : "font-[400]")} text-sm`}>{name}</div>
                </div>
            </div>
        </a>
    );
}