import { useState } from "react"

export interface IScrollableLayoutProps {
    children: React.ReactElement | React.ReactElement[]
}

export default function ScrollableLayout({ children }: IScrollableLayoutProps) {
    const [isScrollbarVisible, setIsScrollbarVisible] = useState<boolean>(false);
    const [scrollbarTimeout, setScrollbarTimeout] = useState<number | null>(null);
    
    const onScrollbarStopped = () => {
        setIsScrollbarVisible(false);
    };

    const onScroll = (event: React.UIEvent<HTMLDivElement>) => {
        setIsScrollbarVisible(true);

        if (scrollbarTimeout !== null) {
            clearTimeout(scrollbarTimeout);
        }

        setScrollbarTimeout(setTimeout(onScrollbarStopped, 500));
    };
    
    return (
        <div className="absolute left-0 right-0 top-0 bottom-0 m-0 h-auto w-auto overflow-hidden z-0 py-1">
            <div className={`relative h-full w-auto max-h-full max-w-full overflow-auto ${(isScrollbarVisible ? "active-scrollbar" : "scrollbar")}`} onScroll={onScroll}>
                {children}
            </div>
        </div>
    );
}