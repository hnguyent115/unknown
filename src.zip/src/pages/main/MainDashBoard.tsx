import Sidebar from "./components/sidebar/Sidebar"
import { Routes, Route } from "react-router-dom"
import Profile from "./components/profile/Profile"
import Chats from "./components/chats/Chats"
import Contacts from "./components/contacts/Contacts"
import Calls from "./components/calls/Calls"

export default function MainDashBoard() {
    return (
        <div className="flex flex-row">
            <Sidebar />
            <div className="relative h-screen min-w-[300px] max-w-[300px]">
                <Routes>
                    <Route path="/" element={<Profile />} />
                    <Route path="/chats" element={<Chats />} />
                    <Route path="/contacts" element={<Contacts />} />
                    <Route path="/calls" element={<Calls />} />
                </Routes>
            </div>
        </div>
    );
}